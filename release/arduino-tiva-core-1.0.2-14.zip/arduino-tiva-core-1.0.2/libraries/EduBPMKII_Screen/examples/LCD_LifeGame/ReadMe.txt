
  LifeGame
  Project
  ----------------------------------
  Developed with embedXcode

  Project LifeGame
  Created by Rei Vilo on 10/12/2013
  Copyright © 2013 Rei Vilo
  License CC = BY SA NC



  References
  ----------------------------------
  * Life_Game_Colour.pde 
    Jul 12, 2012 (c) Rei VILO, 2010-2012
    http://embeddedcomputing.weebly.com/life-game.html

  * Based on (c) Nathan, 11/04/2011 - 20:46
    http://nathandumont.com/node/245

  embedXcode
  embedXcode+
  ----------------------------------
  Embedded Computing on Xcode 4
  Copyright © Rei VILO, 2010-2013
  All rights reserved
  http://embedXcode.weebly.com

